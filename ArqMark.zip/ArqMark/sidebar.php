<div class="sidebar">
	<?php if(!function_exists('dynamic_sidebar') || dynamic_sidebar()): ?>
	<?php endif; ?>
</div>
<br>
<div class='col-100 center' align='center'>

  

</div>

