<div class="search">
	<form action="" method="get" accept-charset="utf-8" id="searchform" role="search">
		<ul>
			<li>
				<input type="text" name="s" id="s" value="Buscar no Site" onblur="if(this.value == '') this.value = 'Buscar no Site';" onfocus="if(this.value == 'Buscar no Site') this.value = '';" />
			</li>	
			<li>	
				<input type="submit" id="searchsubmit" value="OK">
			</li>
		</ul>
	</form>
</div>	