<?php get_header();?>
<div class="col-95 container">
	<div class="left col-75">
		<br>
		<?php if(have_posts()) : 
				while(have_posts()) : the_post();	?>
					<div class="content">			
						<?php the_content(); //lista todo o conteudo ?>			
					</div>			
					<br>
		<?php 	endwhile; 
			else:
			echo '
				<div class="content">			
				Nada encontrado!		
				</div>';
			endif;
		?>
	</div>	
	<div class="left col-25">
		<br><br>
		<?php get_sidebar();?>
		<br>
	</div>	
	<div class="clear"></div>
</div>	
<?php get_footer(); ?>
