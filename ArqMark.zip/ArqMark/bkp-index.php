<?php get_header();?>
<div class="container">
	<div class="left_container">
		<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
		<a href="<?php //the_permalink(); ?>" id="title"><h1><?php the_title();?></h1></a>	
		<div class="content">
			<div class="thumbnail"><?php //the_post_thumbnail(array(198,198));?></div>
			<?php //the_excerpt(); // lista apenas resumos ?>
			<?php //the_content(); //lista todo o conteudo ?>
			<br><br><br><br>
			Publicado em <?php //the_date('d/m/Y');?> - <?php //comments_number("Nenhum comentário","1 comentário", "% comentários");?>
			<div class="info"></div>			
		</div>				
		<br>
		<?php 
			endwhile;
			else:
		?>
		<p>Nenhum post encontrado!</p>
		<?php 
			endif;
		?>
	</div>
	<div class="right_container"><?php //get_sidebar();?></div>
</div>
<div style="clear:both;"></div>
<?php //get_footer(); ?>