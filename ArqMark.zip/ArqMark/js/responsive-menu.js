$(document).ready(function(){
	$('.menu-mobile').click(function(){	
		$('.menu ul').slideToggle();
	});	
	$(window).resize(function(){		
		if( $(window).width() > 480 ){		
			$('.menu ul').removeAttr('style');		
		}		
	});
});