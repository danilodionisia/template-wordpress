<!DOCTYPE HTML>
<html lang="pt-br">
<head>
	<?php define('PATH', 'http://www.arqmarkconsultoria.com.br/wp-content/themes/rca') ;?>
        <?php define('PATH2', 'http://arqmarkconsultoria.com.br/wp-content/uploads/') ;?>
	<meta charset="UTF-8">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo PATH . '/img/logo.ico'; ?>">
	<title><?php bloginfo('name');?> - <?php bloginfo('description');?></title>
	<meta name="generator" content="WordPress <?php bloginfo('version');?>" />
	<meta http-equiv="content-type" content="<?php bloginfo('html_type');?>;<?php bloginfo('charset');?>"/>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url');?>" media="all" type="text/css"/>
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url');?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url');?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url');?>" />	
	<link rel="stylesheet" href="" />
	<script src="<?php echo PATH . '/js/jquery.js'; ?>"></script>
	<script src="<?php echo PATH . '/js/responsive-menu.js'; ?>"></script>
	<?php wp_head();?>
</head>
<body>
	<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.5";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	
	<div class="col-95">
		<div id="header-top">
		
			<div id="header-top-left">
				<a href="<?php echo get_option('home');?>">
					<!--<img class='img3' src="<?php echo PATH . '/img/logo.png'; ?>" />-->
				</a>
			</div>
			
			<div id="header-top-center">
				<a href="<?php echo get_option('home');?>">
					<!--<img class='img5' src="<?php echo PATH . '/img/frase.png'; ?>" />-->
				</a>
			</div>
			
			<div id="header-top-right" align="right">
				<ul>
					<li>
						<a class="social" href="#" target="_blank">
							<img src="<?php echo PATH . '/img/face.fw.png'; ?>" />
						</a>	
					</li>
					<li>
						<a class="social" href="#" target="_blank">
							<img src="<?php echo PATH . '/img/you.fw.png'; ?>" />
						</a>	
					</li>
					<li>	
						<a class="social" href="#" target="_blank">		
						<img src="<?php echo PATH . '/img/insta.fw.png'; ?>" />
						</a>
					</li>				
				</ul>	
			</div>
				
		</div>
	</div>
	
	<div class="clear"></div>
	
	<div class="col-100">
		<nav class="menu">
			<ul>
				<li>
					<a href="<?php echo get_option('home');?>"></a>
				</li>
				<?php wp_list_pages('title_li='); // lista paginas ?>
			</ul>
			<a class="menu-mobile" href="#"><img src="<?php echo PATH . '/img/ico-menu.fw.png'; ?>" /></a>
		</nav>
	</div>
	