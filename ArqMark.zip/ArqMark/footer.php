<!-- Inicio Footer -->
<div id="footer" class="col-100" align="center">
	<div id="footer" class="col-95" align="center">
		
		<div class='col-100 h-15'></div><!-- Ajuste altura -->
		
		<div id="footer-top-center" class='col-100'><!-- Alto footer -->
			<ul>
				<li>
					<a class="social" href="#" target="_blank">
						<img src="<?php echo PATH . '/img/face.fw.png'; ?>" />
					</a>	
				</li>
				<li>	
					<a class="social" href="#" target="_blank">
						<img src="<?php echo PATH . '/img/you.fw.png'; ?>" />
					</a>	
				</li>
				<li>	
					<a class="social" href="#" target="_blank">	
					<img src="<?php echo PATH . '/img/insta.fw.png'; ?>" />
					</a>
				</li>				
			</ul>
		</div><!-- Fim Alto footer -->
		
		<div class='col-100 h-50'></div>
		
		<div id="footer-middle-center"><!-- Meio footer -->
			<div class='left col-50 tleft'>
				<ul>
					<?php wp_list_pages('title_li='); // lista paginas ?>
				</ul>				
			</div>
			<div class='right col-50'>
				<div class='col-100 h-50'></div>
				<br>
				<div class='col-100'align='center'>
	<!--				
	<div class="fb-page" data-href="#" data-width="400" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false">

	<div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/rcaritmos/">
	<a href="https://www.facebook.com/rcaritmos/">
	RCA- Ritmos Camp Academy
	</a>
	</blockquote>
	</div>
	</div>-->
				</div>
				<br>
			</div>
		</div>
		
		<div class='clear col-100 h-60'></div><!-- Fim Meio footer -->	
		
		<div id="footer-bottom-center" align="center"><!-- Baixo footer -->
			<div class='col-100 h-45'>
				<p>
				ArqMark Consultoria &reg; <?php echo date('Y');?> - Todos os Direitos Resevados &copy; 
				<br>
				Developed by JJD Systems
				<br><br>
				</p>
			</div>
		</div><!-- Fim baixo footer -->	
		
		<div class='col-100 h-30'></div>
	</div>		
</div>		
<?php
	wp_footer();
?>

</body>
</html>